Beyond Burnout — Batch 01

01 Getting up
02 Cycling / Slower pedals
03 Mountain climb

Each film: 30 seconds, 1080 x 1920 portrait, 30 fps, English subtitles, no spoken narration.
Each folder includes the MP4, editable SRT captions, a poster image and sound credits.
